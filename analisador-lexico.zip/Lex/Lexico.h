#include <iterator>
#include <iostream>
#include <string>
#include <regex>
#include <list>
#include <map>

using namespace std;

class Lexico {
	
	public:	
	void AnalisadorLexico();
	
	private:


};