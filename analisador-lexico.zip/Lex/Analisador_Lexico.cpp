#include "Lexico.h"

using namespace std;

int main(){
    
	Lexico frase;
	frase.AnalisadorLexico();
	
	return 0;
	
	
    
}